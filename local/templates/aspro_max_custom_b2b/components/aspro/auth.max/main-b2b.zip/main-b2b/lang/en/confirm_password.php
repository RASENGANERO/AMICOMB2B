<?php
$MESS["TITLE"] = 'Confirmation of password';
