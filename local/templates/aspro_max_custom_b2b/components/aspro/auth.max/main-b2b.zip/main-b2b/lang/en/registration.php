<?php
$MESS["TITLE"] = 'Registration';
