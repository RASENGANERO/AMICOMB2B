<?php
$MESS["TITLE"] = 'Confirmation of registration';
